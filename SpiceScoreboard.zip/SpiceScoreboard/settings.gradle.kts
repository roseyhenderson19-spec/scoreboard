rootProject.name = "SpiceScoreboard"
